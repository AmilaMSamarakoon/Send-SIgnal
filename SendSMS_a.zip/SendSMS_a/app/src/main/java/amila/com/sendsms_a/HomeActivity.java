package amila.com.sendsms_a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    ImageButton ImageButtonCritical;
    ImageButton ImageButtonEmergency;
    ImageButton ImageButtonNormal;
    ImageButton ImageButtonCancel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageButtonCritical = (ImageButton) findViewById(R.id.image_button_critical);
        ImageButtonEmergency= (ImageButton) findViewById(R.id.image_button_emergency);
        ImageButtonNormal= (ImageButton) findViewById(R.id.image_button_normal);
        ImageButtonCancel= (ImageButton) findViewById(R.id.image_button_cancel);

        //ImageButtonCritical.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {

            //}
        //});
        //ImageButtonEmergency.setOnClickListener(new View.OnClickListener() {
        //@Override
        //public void onClick(View view) {

        //}
        //});
        //ImageButtonNormal.setOnClickListener(new View.OnClickListener() {
        //@Override
        //public void onClick(View view) {

        //}
        //});
        //ImageButtonCancel.setOnClickListener(new View.OnClickListener() {
        //@Override
        //public void onClick(View view) {

        //}
        //});
    }
}
